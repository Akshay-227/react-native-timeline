// App.tsx

import React from 'react';
import {View} from 'react-native';
import TimelineChart from './src/components/TimelineChart.js';

const App = () => {
  return (
    <View style={{flex: 1}}>
      <TimelineChart />
    </View>
  );
};

export default App;
