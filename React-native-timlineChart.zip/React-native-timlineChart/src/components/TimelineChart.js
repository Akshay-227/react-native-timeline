import React, { useState, useEffect, useRef } from 'react';
import { View, Text, StyleSheet, FlatList } from 'react-native';

const TimelineChart = () => {
  const [currentTime, setCurrentTime] = useState(new Date());
  const flatListRef = useRef(null);

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);

    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    scrollToCurrentTime();
  }, []);

  const scrollToCurrentTime = () => {
    const currentHour = currentTime.getHours();
    flatListRef.current.scrollToIndex({ index: currentHour, animated: true });
  };

  const categories = ['Category 1', 'Category 2', 'Category 3', 'Category 4'];
  const timeSlots = Array.from({ length: 24 }, (_, i) => i);

  // Mock data for events
  const events = {
    'Category 1': [
      { title: 'Event 1', startTime: 13, endTime: 14 },
      { title: 'Event 2', startTime: 14, endTime: 15 },
      { title: 'Event 3', startTime: 15, endTime: 16 },
    ],
    'Category 2': [
      { title: 'Event 4', startTime: 13, endTime: 15 },
      { title: 'Event 5', startTime: 16, endTime: 18 },
    ],
    'Category 3': [
      { title: 'Event 6', startTime: 14, endTime: 16 },
      { title: 'Event 7', startTime: 17, endTime: 19 },
    ],
    'Category 4': [
      { title: 'Event 8', startTime: 15, endTime: 17 },
      { title: 'Event 9', startTime: 18, endTime: 20 },
    ],
  };

  const renderEvents = (category, currentTimeSlot) => {
    // Here you can fetch events for the specific category and time range
    const categoryEvents = events[category];
    const filteredEvents = categoryEvents.filter(
      (event) => currentTimeSlot >= event.startTime && currentTimeSlot < event.endTime
    );

    return filteredEvents.map((event, index) => (
      <View key={index} style={styles.event}>
        <Text>{event.title}</Text>
      </View>
    ));
  };

  const getItemLayout = (data, index) => ({
    length: 50, // Assuming each item has a height of 50 (adjust as needed)
    offset: 50 * index,
    index,
  });

  return (
    <View style={styles.container}>
      <View style={styles.chart}>
        <FlatList
          ref={flatListRef}
          data={timeSlots}
          horizontal
          renderItem={({ item }) => (
            <View key={item} style={styles.timeSlot}>
              <Text style={styles.timeText}>{item}:00</Text>
              {item === currentTime.getHours() && (
                <View style={styles.currentTimeIndicator} />
              )}
              {/* Render events for each category */}
              {categories.map((category) => renderEvents(category, item))}
            </View>
          )}
          keyExtractor={(item) => item.toString()}
          getItemLayout={getItemLayout}
          contentContainerStyle={{ paddingBottom: 20 }} // Add paddingBottom to ensure the last item is visible after scrolling
        />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  chart: {
    flex: 1,
    paddingBottom: 10,
  },
  timeSlot: {
    flexDirection: 'column',
    alignItems: 'center',
    borderBottomWidth: 1,
    borderColor: '#ccc',
    paddingTop: 5,
    paddingBottom: 10,
    position: 'relative',
  },
  timeText: {
    marginRight: 10,
  },
  currentTimeIndicator: {
    position: 'absolute',
    backgroundColor: 'red',
    height: '100%',
    width: 2,
    zIndex: 1,
    left: 50,
  },
  event: {
    backgroundColor: 'blue',
    paddingVertical: 5,
    paddingHorizontal: 10,
    marginBottom: 5,
  },
});

export default TimelineChart;
